#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
    Trabalho de estrutura de dados 1, Arvore genealogica usando Arvore binaria de busca.
*/



typedef struct {
    char name[50], sexo, locNas[50];
    int anoNasc, anoOb;
}Pessoa;

typedef struct no{
    Pessoa pessoa;
    struct no *fillhoEsq, *filhoDir;
}NoArv;

Pessoa criarPessoa(){
    Pessoa p;
    fflush(stdin);
    printf("\nDigite o nome da pessoa: ");
    fgets(p.name, 49, stdin);
    p.name[strcspn(p.name, "\n")] = '\0';
    printf("\nDigite o local de nascimento: ");
    fgets(p.locNas, 49, stdin);
    p.locNas[strcspn(p.locNas, "\n")] = '\0';
    printf("\nDigite o sexo (f/m): ");
    scanf(" %c",&p.sexo);
    printf("\nDigite o ano do nascimento: ");
    scanf("%d",&p.anoNasc);
    fflush(stdin);
    printf("\nDigite o ano de obito: ");
    scanf("%d",&p.anoOb);
    fflush(stdin);
    return p;
}

void imprimirPessoa(Pessoa p){
    printf("\n------------Dados------------\n");
    printf("\nNome: %s;",p.name);
    printf("\nSexo: %c",p.sexo);
    printf("\nAno de nascimento: %i",p.anoNasc);
    printf("\nAno de obito: %i",p.anoOb);
    printf("\nLocal de nascimento: %s",p.locNas);
    printf("\n-----------------------------\n");
}
NoArv* inserirPessoa(NoArv *raiz, Pessoa p){
    if(raiz == NULL){
        NoArv *aux = malloc(sizeof(NoArv));
        aux->pessoa = p;
        aux->filhoDir = NULL;
        aux->fillhoEsq = NULL;
        return aux;
    } else {
        if(p.sexo == 'f')
            raiz->fillhoEsq = inserirPessoa(raiz->fillhoEsq, p);
        else
            raiz->filhoDir = inserirPessoa(raiz->filhoDir, p);
        return raiz;
    }
}

NoArv* buscaPessoa(NoArv* raiz,char nome[], char bSexo){
    int res = strcmp(raiz->pessoa.name, nome);
    if(raiz){
        if(res == 0)
            return raiz;
        else if(bSexo == 'f')
            return buscaPessoa(raiz->fillhoEsq,nome , bSexo);
        else
            return buscaPessoa(raiz->filhoDir,nome, bSexo);
    }
    return NULL;
}


int altura(NoArv *raiz){
    if(raiz == NULL){
        printf("\nArvore Nula!!");
        return 0;
    }else {
    int fEsq = altura(raiz->fillhoEsq);
    int fDir = altura(raiz->filhoDir);
    if(fEsq > fDir)
        return fEsq+1;
    else
        return fDir+1;
    }
}
int quantNos(NoArv *raiz){
    if(raiz == NULL)
        return 0;
    else
        return 1 + quantNos(raiz->fillhoEsq) + quantNos(raiz->filhoDir);
}

int quantFolha(NoArv *raiz){
    if(raiz ==NULL)
        return 0;
    else if(raiz->fillhoEsq == NULL && raiz->filhoDir == NULL)
        return 1;
    else
        return quantFolha(raiz->fillhoEsq) + quantFolha(raiz->filhoDir);
}

NoArv* remover(NoArv *raiz, char chave[],char sexo){
    if(raiz == NULL){
        printf("\nValor nao encontrado!\n");
        return NULL;
    } else { // procura o valor a ser removido.
       int res = strcmp(raiz->pessoa.name,chave);
        if(res == 0){
        //remove nos folhas.
        if(raiz->fillhoEsq == NULL && raiz->filhoDir == NULL){
            free(raiz);
            printf("\nElemento folha removido: %s !\n", chave);
            return NULL;
        } else {
            //remove n�s que possuem dois filhos
            if(raiz->fillhoEsq != NULL && raiz->filhoDir != NULL){
                Pessoa  p;
                NoArv *aux = raiz->fillhoEsq;
                while(aux->filhoDir != NULL) // vou percorrer o valor mais a direita do filho da esquerda
                aux = aux->filhoDir;
                p = raiz->pessoa;
                raiz->pessoa = aux->pessoa;
                aux->pessoa = p;
                printf("\nElemento trocado: %s\n", chave);
                raiz->fillhoEsq = remover(raiz->fillhoEsq, chave, sexo);
                return raiz;
            }else {
            NoArv *aux;
            if(raiz->fillhoEsq != NULL)
                aux = raiz->fillhoEsq;
            else
                aux = raiz->filhoDir;
            free(raiz);
            printf("\nElemento com 1 filho removido: %s\n",chave);
            return aux;
            }
        }
    } else {
        if(sexo == 'f')
            raiz->fillhoEsq = remover(raiz->fillhoEsq, chave, sexo);
        else
            raiz->filhoDir = remover(raiz->filhoDir, chave, sexo);
        return raiz;
        }
    }
}

void imprimirArvore(NoArv *raiz){
    if(raiz){
        imprimirPessoa(raiz->pessoa);
        imprimirArvore(raiz->fillhoEsq);
        imprimirArvore(raiz->filhoDir);
    }
}


int main() {
    NoArv *arvore = NULL;

   int opcao;

    while (1) {
       /* if(arvore){
        printf("\n\nraiz: \n\n");
        imprimirPessoa(arvore->pessoa);
        if(arvore->fillhoEsq){
        printf("\nFilho esquerdo:");
        imprimirPessoa(arvore->fillhoEsq->pessoa);
        }
        if(arvore->filhoDir){
        printf("\nFilho direito: ");
        imprimirPessoa(arvore->filhoDir->pessoa);
        }
        }*/
        printf("\n*** ARVORE DE PESQUISA ***\n");
        printf("1. Inserir pessoa.\n");
        printf("2. Buscar pessoa.\n");
        printf("3. Remover pessoa.\n");
        printf("4. Imprimir arvore.\n");
        printf("5. Sair.\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: {
                Pessoa p1 = criarPessoa();
                arvore = inserirPessoa(arvore, p1);
                    }

                break;

            case 2: {
                char nome[30], sexo; // Agora a declara��o da vari�vel cpf est� dentro do escopo do bloco
                printf("Digite o nome que deseja buscar: ");
                fflush(stdin);
                fgets(nome, 29, stdin);
                nome[strcspn(nome, "\n")] = '\0';
                printf("\nDigite o sexo: ");
                scanf(" %c",&sexo);
                NoArv *resultado = buscaPessoa(arvore,nome,sexo);
                if (resultado != NULL) {
                    imprimirPessoa(resultado->pessoa);
                } else {
                    printf("Pessoa nao encontrada!\n");
                }
                break;
            }
            case 3: {
                char chave[30], sexo; // Agora a declara��o da vari�vel chave est� dentro do escopo do bloco
                printf("Digite o nome da pessoa a remover: ");
                fflush(stdin);
                fgets(chave, 29, stdin);
                chave[strcspn(chave, "\n")] = '\0';
                printf("\nDigite o sexo da pessoa (f/m): ");
                scanf(" %c",&sexo);
                arvore = remover(arvore, chave, sexo);
                break;
                }
            case 4:{
                imprimirArvore(arvore);
                break;
            }
            case 5:{
                exit(0);
                break;
            }

            default:
                printf("Opcao invalida!\n");
                break;
        }
    }


    return 0;
}
